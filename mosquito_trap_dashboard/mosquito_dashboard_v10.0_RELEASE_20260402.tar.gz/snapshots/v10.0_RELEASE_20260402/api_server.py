from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import sqlite3
import os

app = Flask(__name__)
CORS(app)

project_path = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.join(project_path, 'data', 'mosquito_trap_dashboard.db')
TABLE_NAME = 'raw_data'
APP_PORT = int(os.environ.get('MOSQ_PORT', '7807'))
APP_DEBUG = os.environ.get('MOSQ_DEBUG', '0').strip().lower() in ('1', 'true', 'yes', 'on')
APP_HOST = os.environ.get('MOSQ_HOST', '0.0.0.0')
DEBUG_DB_PATH = os.environ.get('MOSQ_DB_PATH', '').strip()
if DEBUG_DB_PATH:
    db_path = DEBUG_DB_PATH

def get_db_connection():
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def _build_where_clause(args):
    """Builds WHERE clause and parameters from request args."""
    conditions = []
    params = []
    
    # Area filter
    area = args.get('area')
    if area:
        conditions.append("COALESCE(NULLIF(city, ''), NULLIF(location_name, ''), NULLIF(state, ''), NULLIF(subregion, ''), NULLIF(lga, ''), 'Unknown Area') = ?")
        params.append(area)
        
    # Trap filter
    trap = args.get('trap_id')
    if trap:
        conditions.append("COALESCE(NULLIF(sitecode_cd, ''), NULLIF(agency_cd, ''), NULLIF(name, ''), 'Unknown Trap') = ?")
        params.append(trap)
        
    # Start date filter
    start_date = args.get('start_date')
    if start_date:
        conditions.append("date >= ?")
        params.append(start_date)
        
    # End date filter
    end_date = args.get('end_date')
    if end_date:
        conditions.append("date <= ?")
        params.append(end_date)
        
    where_clause = " AND ".join(conditions)
    if where_clause:
        where_clause = "WHERE " + where_clause
        
    return where_clause, params

@app.route('/api/table', methods=['GET'])
def get_table_data():
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 50))
        offset = (page - 1) * limit
        
        where_clause, params = _build_where_clause(request.args)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get total count for pagination
        count_query = f"SELECT COUNT(*) FROM {TABLE_NAME} {where_clause}"
        cursor.execute(count_query, params)
        total_records = cursor.fetchone()[0]
        
        # Get paginated data
        query = f"""
            SELECT
                date,
                COALESCE(NULLIF(city, ''), NULLIF(location_name, ''), NULLIF(state, ''), NULLIF(subregion, ''), NULLIF(lga, ''), 'Unknown Area') AS area,
                COALESCE(NULLIF(sitecode_cd, ''), NULLIF(agency_cd, ''), NULLIF(name, ''), 'Unknown Trap') AS trap,
                COALESCE(NULLIF(detected_name, ''), NULLIF(orig_detected_name, ''), 'Unknown Species') AS mosquito_name,
                1 AS number_of_mosquitoes,
                latitude,
                longitude
            FROM {TABLE_NAME}
            {where_clause}
            ORDER BY date DESC
            LIMIT ? OFFSET ?
        """
        cursor.execute(query, params + [limit, offset])
        rows = [dict(row) for row in cursor.fetchall()]
        
        return jsonify({
            "data": rows,
            "pagination": {
                "page": page,
                "limit": limit,
                "total_records": total_records,
                "total_pages": (total_records + limit - 1) // limit
            }
        })
    except Exception as e:
        print(f"Error fetching table data: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/api/kpi', methods=['GET'])
def get_kpi_data():
    try:
        where_clause, params = _build_where_clause(request.args)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = f"""
            SELECT
                COUNT(*) AS total_records,
                COUNT(DISTINCT COALESCE(NULLIF(city, ''), NULLIF(location_name, ''), NULLIF(state, ''), NULLIF(subregion, ''), NULLIF(lga, ''), 'Unknown Area')) AS total_areas,
                COUNT(DISTINCT COALESCE(NULLIF(sitecode_cd, ''), NULLIF(agency_cd, ''), NULLIF(name, ''), 'Unknown Trap')) AS total_traps,
                COUNT(*) AS total_mosquitoes
            FROM {TABLE_NAME}
            {where_clause}
        """
        cursor.execute(query, params)
        kpi = dict(cursor.fetchone())
        
        return jsonify(kpi)
    except Exception as e:
        print(f"Error fetching KPI data: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/api/chart/bar', methods=['GET'])
def get_bar_chart_data():
    try:
        where_clause, params = _build_where_clause(request.args)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = f"""
            SELECT
                COALESCE(NULLIF(detected_name, ''), NULLIF(orig_detected_name, ''), 'Unknown Species') AS species,
                COUNT(*) as count
            FROM {TABLE_NAME}
            {where_clause}
            GROUP BY species
            ORDER BY count DESC
            LIMIT 10
        """
        cursor.execute(query, params)
        data = [dict(row) for row in cursor.fetchall()]
        
        return jsonify(data)
    except Exception as e:
        print(f"Error fetching bar chart data: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/api/chart/line', methods=['GET'])
def get_line_chart_data():
    try:
        where_clause, params = _build_where_clause(request.args)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = f"""
            SELECT
                date,
                COUNT(*) as count
            FROM {TABLE_NAME}
            {where_clause}
            GROUP BY date
            ORDER BY date ASC
        """
        cursor.execute(query, params)
        data = [dict(row) for row in cursor.fetchall()]
        
        return jsonify(data)
    except Exception as e:
        print(f"Error fetching line chart data: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/api/map', methods=['GET'])
def get_map_data():
    try:
        where_clause, params = _build_where_clause(request.args)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = f"""
            SELECT
                latitude,
                longitude,
                COALESCE(NULLIF(sitecode_cd, ''), NULLIF(agency_cd, ''), NULLIF(name, ''), 'Unknown Trap') AS trap,
                COALESCE(NULLIF(city, ''), NULLIF(location_name, ''), NULLIF(state, ''), NULLIF(subregion, ''), NULLIF(lga, ''), 'Unknown Area') AS area,
                COUNT(*) as count
            FROM {TABLE_NAME}
            {where_clause}
            GROUP BY latitude, longitude, trap, area
        """
        cursor.execute(query, params)
        data = [dict(row) for row in cursor.fetchall()]
        
        return jsonify(data)
    except Exception as e:
        print(f"Error fetching map data: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/api/filters/areas', methods=['GET'])
def get_areas():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = f"SELECT DISTINCT COALESCE(NULLIF(city, ''), NULLIF(location_name, ''), NULLIF(state, ''), NULLIF(subregion, ''), NULLIF(lga, ''), 'Unknown Area') as area FROM {TABLE_NAME} ORDER BY area"
        cursor.execute(query)
        data = [row['area'] for row in cursor.fetchall() if row['area']]
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/api/filters/traps', methods=['GET'])
def get_traps():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        area = request.args.get('area')
        
        query = "SELECT DISTINCT COALESCE(NULLIF(sitecode_cd, ''), NULLIF(agency_cd, ''), NULLIF(name, ''), 'Unknown Trap') as trap FROM " + TABLE_NAME
        params = []
        if area:
            query += " WHERE COALESCE(NULLIF(city, ''), NULLIF(location_name, ''), NULLIF(state, ''), NULLIF(subregion, ''), NULLIF(lga, ''), 'Unknown Area') = ?"
            params.append(area)
            
        query += " ORDER BY trap"
        cursor.execute(query, params)
        data = [row['trap'] for row in cursor.fetchall() if row['trap']]
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/')
def serve_dashboard():
    return send_from_directory(project_path, 'dashboard_v10.html')

@app.route('/<path:filename>')
def serve_static(filename):
    return send_from_directory(project_path, filename)

if __name__ == '__main__':
    print(f"Starting API server at http://127.0.0.1:{APP_PORT}")
    print(f"  - Dashboard: http://127.0.0.1:{APP_PORT}/")
    print(f"  - Debug: {'ON' if APP_DEBUG else 'OFF'} (set MOSQ_DEBUG=1 to enable)")
    app.run(host=APP_HOST, port=APP_PORT, debug=APP_DEBUG, use_reloader=APP_DEBUG)
